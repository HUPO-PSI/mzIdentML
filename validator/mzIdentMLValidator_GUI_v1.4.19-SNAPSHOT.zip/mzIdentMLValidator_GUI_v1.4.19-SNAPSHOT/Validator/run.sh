#!/bin/bash
java -Xms2048m -jar mzIdentMLValidator-1.4.19-SNAPSHOT.jar
