#!/bin/bash
java -Xms2048m -jar mzIdentMLValidator-1.4.35-SNAPSHOT.jar
