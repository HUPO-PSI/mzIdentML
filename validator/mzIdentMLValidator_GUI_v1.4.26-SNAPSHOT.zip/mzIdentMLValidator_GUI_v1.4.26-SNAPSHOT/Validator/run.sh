#!/bin/bash
java -Xms2048m -jar mzIdentMLValidator-1.4.26-SNAPSHOT.jar
