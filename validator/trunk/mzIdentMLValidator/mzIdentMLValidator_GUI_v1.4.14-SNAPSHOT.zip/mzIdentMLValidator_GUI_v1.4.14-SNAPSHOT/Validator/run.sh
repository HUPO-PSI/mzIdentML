#!/bin/bash
java -Xms2048m -jar mzIdentMLValidator-1.4.14-SNAPSHOT.jar
