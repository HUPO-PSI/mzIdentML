#!/bin/bash
java -Xms2048m -jar mzIdentMLValidator-1.4.16-SNAPSHOT.jar
