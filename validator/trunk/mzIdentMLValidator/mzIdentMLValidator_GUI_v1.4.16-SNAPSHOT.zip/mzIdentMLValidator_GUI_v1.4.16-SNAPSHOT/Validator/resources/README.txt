Configuration resource files:
- mzIdentML-mapping.xml: cv rules for semantic validation of mzIdentML
- miape-msi-rules.xml: cv rules for MIAPE compliance validation of mzIdentML
- ObjectRules.xml: object rules for semantic validation of mzIdentML
- ObjectRulesMIAPE.xml: object rules for MIAPE compliance validation of mzIdentML
- ontologies.xml: file that determines how to read the ontology resources
- ruleFilter_MIAPEMSI.xml: xml file that determine conditionalities in the rules

Note that these files will be overriden by others if found in the application path